#!/usr/bin/python

import heapq
import string
import csv
from operator import itemgetter
from rouge_score import rouge_scorer
import itertools
import networkx as nx
import numpy as np
import pydeepl
from transformers import MarianMTModel, MarianTokenizer

import dataset

target_model_name = 'Helsinki-NLP/opus-mt-en-ROMANCE'
target_tokenizer = MarianTokenizer.from_pretrained(target_model_name)
target_model = MarianMTModel.from_pretrained(target_model_name)

en_model_name = 'Helsinki-NLP/opus-mt-ROMANCE-en'
en_tokenizer = MarianTokenizer.from_pretrained(en_model_name)
en_model = MarianMTModel.from_pretrained(en_model_name)
Corpus = dataset.Dataset()

class Translate:

    def __init__(self):
        """
        """

        self.list_of_jaccard_coefficients = []
        self.dict_of_translations = {}

    def translate(self, texts, model, tokenizer, language):
        template = lambda text: f"{text}" if language == "en" else f">>{language}<< {text}"
        src_texts = [template(text) for text in texts]

        encoded = tokenizer.prepare_seq2seq_batch(src_texts)

        translated = model.generate(**encoded)

        translated_texts = tokenizer.batch_decode(translated, skip_special_tokens=True)
        return translated_texts

    def backtranslate(self, corpus, destination_language):
        """
        Translate to a language and then translate back.
        """

        for index, original_language in enumerate(corpus):
            title = []
            title.append(original_language)
            english_graph, english_labels = Corpus.set_edges_and_nodes(title[0])
            target_language = self.translate(title, target_model, target_tokenizer, language=destination_language)

            target_language_to_english = self.translate(target_language, en_model, en_tokenizer, language="en")
            target_language_to_english_graph, target_language_to_english_labels = Corpus.set_edges_and_nodes(target_language_to_english[0])

            jaccard_coefficient = self.calculate_jaccard_coefficient(title[0].split(), target_language_to_english[0].split())
            self.list_of_jaccard_coefficients.append(jaccard_coefficient)

            scores = self.get_rouge_metric(title[0], target_language_to_english[0])
            self.dict_of_translations[index] = { 
                "Original": title[0],
                "Original edges": english_graph.edges,
                "Translated": target_language_to_english[0],
                "Translated edges": target_language_to_english_graph.edges,
                "Jaccard coefficient": jaccard_coefficient,
                "rouge1 precision": scores['rouge1'].precision,
                "rouge1 recall": scores['rouge1'].recall,
                "rouge1 fmeasure": scores['rouge1'].fmeasure,
                "rougeL precision": scores['rougeL'].precision,
                "rougeL recall": scores['rougeL'].recall,
                "rougeL fmeasure": scores['rougeL'].fmeasure
                }
            print(index)
        self.write_to_csv(self.dict_of_translations)    
        total = sum(self.list_of_jaccard_coefficients) / len(self.list_of_jaccard_coefficients)
        print("The average jaccard coefficient is: ")
        print(round(total, 3))   

    def backtranslate_3_hops(self, corpus, destination_language):
        """
        Translate to a language and then translate back x times.
        """

        for index, original_language in enumerate(corpus):
            title = []
            title.append(original_language)
            english_graph, english_labels = Corpus.set_edges_and_nodes(title[0])
            target_language = self.translate(title, target_model, target_tokenizer, language=destination_language)

            target_language_to_english = self.translate(target_language, en_model, en_tokenizer, language="en")

            back_to_target_language = self.translate(target_language_to_english, target_model, target_tokenizer, language=destination_language)
            back_to_english = self.translate(back_to_target_language, en_model, en_tokenizer, language="en")
            back_to_english_graph, back_to_english_labels = Corpus.set_edges_and_nodes(back_to_english[0])

            jaccard_coefficient = self.calculate_jaccard_coefficient(title[0].split(), back_to_english[0].split())
            self.list_of_jaccard_coefficients.append(jaccard_coefficient)

            scores = self.get_rouge_metric(title[0], back_to_english[0])
            self.dict_of_translations[index] = { 
                "Original": title[0],
                "Original edges": english_graph.edges,
                "Translated": back_to_english[0],
                "Translated edges": back_to_english_graph.edges,
                "Jaccard coefficient": jaccard_coefficient,
                "rouge1 precision": scores['rouge1'].precision,
                "rouge1 recall": scores['rouge1'].recall,
                "rouge1 fmeasure": scores['rouge1'].fmeasure,
                "rougeL precision": scores['rougeL'].precision,
                "rougeL recall": scores['rougeL'].recall,
                "rougeL fmeasure": scores['rougeL'].fmeasure
                }
            print(index)
        self.write_to_csv(self.dict_of_translations)    
        total = sum(self.list_of_jaccard_coefficients) / len(self.list_of_jaccard_coefficients)
        print("The average jaccard coefficient is: ")
        print(round(total, 3))

    def backtranslate_4_hops(self, corpus, destination_language):
        """
        Translate to a language and then translate back x times.
        """

        for index, original_language in enumerate(corpus):
            title = []
            title.append(original_language)
            english_graph, english_labels = Corpus.set_edges_and_nodes(title[0])
            target_language = self.translate(title, target_model, target_tokenizer, language=destination_language)

            target_language_to_english = self.translate(target_language, en_model, en_tokenizer, language="en")

            back_to_target_language = self.translate(target_language_to_english, target_model, target_tokenizer, language=destination_language)

            first_back_to_english = self.translate(back_to_target_language, en_model, en_tokenizer, language="en")

            again_back_to_target = self.translate(first_back_to_english, target_model, target_tokenizer, language=destination_language)

            back_to_english = self.translate(again_back_to_target, en_model, en_tokenizer, language="en")
            back_to_english_graph, back_to_english_labels = Corpus.set_edges_and_nodes(back_to_english[0])

            jaccard_coefficient = self.calculate_jaccard_coefficient(title[0].split(), back_to_english[0].split())
            self.list_of_jaccard_coefficients.append(jaccard_coefficient)

            scores = self.get_rouge_metric(title[0], back_to_english[0])
            self.dict_of_translations[index] = { 
                "Original": title[0],
                "Original edges": english_graph.edges,
                "Translated": back_to_english[0],
                "Translated edges": back_to_english_graph.edges,
                "Jaccard coefficient": jaccard_coefficient,
                "rouge1 precision": scores['rouge1'].precision,
                "rouge1 recall": scores['rouge1'].recall,
                "rouge1 fmeasure": scores['rouge1'].fmeasure,
                "rougeL precision": scores['rougeL'].precision,
                "rougeL recall": scores['rougeL'].recall,
                "rougeL fmeasure": scores['rougeL'].fmeasure
                }
            print(index)
        self.write_to_csv(self.dict_of_translations)    
        total = sum(self.list_of_jaccard_coefficients) / len(self.list_of_jaccard_coefficients)
        print("The average jaccard coefficient is: ")
        print(round(total, 3))
    
    def calculate_jaccard_coefficient(self, original, candidate):
        """
        Calculate the jaccard similarity coefficient.
        """

        original_lower_case = [word.lower() for word in original]
        candidate_lower_case = [word.lower() for word in candidate]
        intersection = len(list(set(original_lower_case).intersection(candidate_lower_case)))
        union = (len(original_lower_case) + len(candidate_lower_case)) - intersection
        return round((float(intersection) / union), 2)
    
    def get_lowest_jaccard_coefficients(self, n):
        """
        n is the degree from the min.
        """

        smallest_dicts = heapq.nsmallest(n, self.dict_of_translations.values(), key=lambda x:x['Jaccard coefficient'])
        for coefficient in smallest_dicts:
            print(coefficient['Original'])
            print(coefficient['Translated'])
            print(coefficient['Jaccard coefficient'])
            print("")
    
    def get_highest_jaccard_coefficients(self, n):
        """
        n is the degree from the min.
        """

        largest_dicts = heapq.nlargest(n, self.dict_of_translations.values(), key=lambda x:x['Jaccard coefficient'])
        for coefficient in largest_dicts:
            print(coefficient['Original'])
            print(coefficient['Translated'])
            print(coefficient['Jaccard coefficient'])
            print("")
    
    def get_rouge_metric(self, original_english, translated_english):
        """
        """

        # Rouge returns the score beyween CANDIDATE, REFERENCE
        # So, ORIGINAL_ENGLISH, TRANSLATED_ENGLISH
        #rouge1 = unigram (each word)
        # rougeL = longest common subsequence, LCS
        scorer = rouge_scorer.RougeScorer(['rouge1', 'rougeL'], use_stemmer=True)
        scores = scorer.score(original_english, translated_english)
        return scores
    
    def mergedict(self, a,b):
        a.update(b)
        return a
    
    def write_to_csv(self, dictionary):
        """
        Write a dict as a csv file.
        """
        headers = ['Original', 'Original edges', 'Translated', 'Translated edges', 'Jaccard coefficient',
                    'rouge1 precision', 'rouge1 recall', 'rouge1 fmeasure', 'rougeL precision', 'rougeL recall',
                    'rougeL fmeasure']
        with open("en.it.en.it.en.it.en.csv", "w", encoding="utf-8") as f:
            w = csv.DictWriter(f, headers)
            w.writeheader()
            for k,d in sorted(dictionary.items()):
                w.writerow(self.mergedict({'Jaccard coefficient': k},d))
    
    def divide_chunks(self, l, n):
        """
        For CUDA parallel processing.
        Currently doesn't work, my GPU seems busted....?
        """
        for i in range(0, len(l), n):
            yield l[i:i + n]

if __name__ == "__main__":
    Translated = Translate()
    original_english = Corpus.get_list_of_literal_titles()
    Translated.backtranslate_4_hops(original_english, "it")
